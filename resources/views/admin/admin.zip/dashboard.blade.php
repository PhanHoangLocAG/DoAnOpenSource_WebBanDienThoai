@extends('admin.layouts.index')

@section('content')

<div id="page-wrapper">

    <div class="card bg-primary text-white">
        <div class="card-body">Chào mừng bạn đến với cửa hàng điện thoại di động</div>
    </div>
            <!-- /.container-fluid -->
</div>

@endsection